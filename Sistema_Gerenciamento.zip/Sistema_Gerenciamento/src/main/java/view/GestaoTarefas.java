package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import model.Robo;

public class GestaoTarefas extends JFrame {

    private JTable tabelaRobos;
    private DefaultTableModel modeloTabela;
    private JTextField campoTarefa;
    private JButton botaoAtribuirTarefa;
    private JButton botaoConcluirTarefa;

    public GestaoTarefas(List<Robo> robos) {
        setTitle("Gestão de Tarefas");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] colunas = {"Nome do Robô", "Tarefa Atribuída"};
        modeloTabela = new DefaultTableModel(colunas, 0);

        for (Robo robo : robos) {
            modeloTabela.addRow(new Object[]{robo.getNome(), ""});
        }

        tabelaRobos = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabelaRobos);
        add(scrollPane, BorderLayout.CENTER);

        JPanel painelTarefa = new JPanel();
        painelTarefa.setLayout(new FlowLayout());

        campoTarefa = new JTextField(20);
        painelTarefa.add(new JLabel("Tarefa:"));
        painelTarefa.add(campoTarefa);

        botaoAtribuirTarefa = new JButton("Atribuir Tarefa");
        botaoAtribuirTarefa.addActionListener(this::atribuirTarefa);
        painelTarefa.add(botaoAtribuirTarefa);

        botaoConcluirTarefa = new JButton("Marcar Como Concluída");
        botaoConcluirTarefa.addActionListener(this::concluirTarefa);
        painelTarefa.add(botaoConcluirTarefa);

        add(painelTarefa, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void atribuirTarefa(ActionEvent e) {
        int linhaSelecionada = tabelaRobos.getSelectedRow();
        if (linhaSelecionada != -1) {
            String tarefa = campoTarefa.getText();
            modeloTabela.setValueAt(tarefa, linhaSelecionada, 1);
            campoTarefa.setText(""); 
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um robô para atribuir a tarefa.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void concluirTarefa(ActionEvent e) {
       
        int linhaSelecionada = tabelaRobos.getSelectedRow();
        if (linhaSelecionada != -1) {
            String tarefa = (String) modeloTabela.getValueAt(linhaSelecionada, 1);
            if (!tarefa.isEmpty()) {
                modeloTabela.setValueAt(tarefa + " (Concluída)", linhaSelecionada, 1);
            } else {
                JOptionPane.showMessageDialog(this, "Nenhuma tarefa atribuída para marcar como concluída.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um robô para marcar a tarefa como concluída.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        List<Robo> robos = List.of(
            new Robo("Robo1", "Status1", "Tipo1"),
            new Robo("Robo2", "Status2", "Tipo2")
        );

        javax.swing.SwingUtilities.invokeLater(() -> new GestaoTarefas(robos).setVisible(true));
    }
}
