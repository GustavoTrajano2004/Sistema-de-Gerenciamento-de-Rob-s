package view;

import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import model.Robo;
import model.RoboLoader;


public class TelaEntrada extends javax.swing.JFrame {

   private CadastroRobos cadastroRobos;
   
   public TelaEntrada(String nome, CadastroRobos cadastroRobos1) {
        initComponents();
    }
   
   public TelaEntrada(String nomeUsuario) {
    initComponents();
    bemVindo.setText("Seja bem-vindo, " + nomeUsuario + "!");
    }

    TelaEntrada() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
   
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        bemVindo = new javax.swing.JLabel();
        ManRobos = new javax.swing.JButton();
        cadRobo = new javax.swing.JButton();
        gestaoTarefas = new javax.swing.JButton();
        monStatus = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton5.setText("X");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        ManRobos.setBackground(new java.awt.Color(51, 51, 51));
        ManRobos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ManRobos.setForeground(new java.awt.Color(255, 255, 255));
        ManRobos.setText("Manutenção de Robôs");
        ManRobos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManRobosActionPerformed(evt);
            }
        });

        cadRobo.setBackground(new java.awt.Color(51, 51, 51));
        cadRobo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cadRobo.setForeground(new java.awt.Color(255, 255, 255));
        cadRobo.setText("Cadastro de Robôs");
        cadRobo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadRoboActionPerformed(evt);
            }
        });

        gestaoTarefas.setBackground(new java.awt.Color(51, 51, 51));
        gestaoTarefas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        gestaoTarefas.setForeground(new java.awt.Color(255, 255, 255));
        gestaoTarefas.setText("Gestão de Tarefas");
        gestaoTarefas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestaoTarefasActionPerformed(evt);
            }
        });

        monStatus.setBackground(new java.awt.Color(51, 51, 51));
        monStatus.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        monStatus.setForeground(new java.awt.Color(255, 255, 255));
        monStatus.setText("Monitoramento de Status");
        monStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monStatusActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton6.setText("X");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(267, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bemVindo, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cadRobo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(gestaoTarefas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ManRobos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(monStatus, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)))
                .addGap(239, 239, 239))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton6))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton6)
                .addGap(10, 10, 10)
                .addComponent(bemVindo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cadRobo, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(gestaoTarefas, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(monStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ManRobos, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(214, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void ManRobosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManRobosActionPerformed

        ManutencaoRobos manutencaoRobos = new ManutencaoRobos();
    
        manutencaoRobos.setVisible(true);    
    }//GEN-LAST:event_ManRobosActionPerformed

    private void cadRoboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadRoboActionPerformed

    JFrame frame = new JFrame("Cadastro de Robôs");
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    frame.setSize(800, 500);
    frame.setLocationRelativeTo(null); 

    CadRobo cadastroPanel = new CadRobo();
    frame.getContentPane().add(cadastroPanel);
    frame.setVisible(true);

    this.setVisible(false);
    }//GEN-LAST:event_cadRoboActionPerformed

    
    
    private void gestaoTarefasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestaoTarefasActionPerformed
        
        List<Robo> listaRobos = RoboLoader.carregarRobosDeArquivo("robos.txt");

        if (listaRobos != null && !listaRobos.isEmpty()) {
            new GestaoTarefas(listaRobos).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Não há robôs cadastrados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_gestaoTarefasActionPerformed

    public interface TelaAnterior {
    void mostrar();
    }
    
    public class CadastroRobos extends javax.swing.JFrame implements TelaAnterior {
        @Override
        public void mostrar() {
            this.setVisible(true);
            }
    }
    
    private void monStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monStatusActionPerformed

        List<Robo> listaRobos = RoboLoader.carregarRobosDeArquivo("robos.txt");

        if (listaRobos != null) {
            System.out.println("Lista de Robôs carregada: " + listaRobos.size() + " robôs encontrados.");
        } else {
            System.out.println("Lista de Robôs é nula.");
        }

        if (listaRobos != null && !listaRobos.isEmpty()) {
            new ListaRobosView(listaRobos).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Não há robôs cadastrados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_monStatusActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

     public static void main(String args[]) {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaEntrada tela = new TelaEntrada("Usuário");
                tela.setVisible(true);
            }
        });
    }
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ManRobos;
    private javax.swing.JLabel bemVindo;
    private javax.swing.JButton cadRobo;
    private javax.swing.JButton gestaoTarefas;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton monStatus;
    // End of variables declaration//GEN-END:variables
}