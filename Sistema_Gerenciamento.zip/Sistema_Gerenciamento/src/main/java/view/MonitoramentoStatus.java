package view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import model.Robo;
import model.RoboLoader;

public class MonitoramentoStatus extends JFrame {

    public MonitoramentoStatus() {
        setTitle("Monitoramento de Status");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();

        JButton btnListaRobos = new JButton("Exibir Lista de Robôs");
        btnListaRobos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Robo> robos = RoboLoader.carregarRobosDeArquivo("robos.txt");

                if (robos != null && !robos.isEmpty()) {
                    new ListaRobos(robos).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(MonitoramentoStatus.this, "Não há robôs cadastrados.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(btnListaRobos);
        add(panel);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new MonitoramentoStatus().setVisible(true));
    }
}
