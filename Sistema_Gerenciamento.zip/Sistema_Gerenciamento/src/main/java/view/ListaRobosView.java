package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import model.Robo;

public class ListaRobosView extends JFrame {
    private JTable robosTable;
    private DefaultTableModel tableModel;

    public ListaRobosView(List<Robo> listaRobos) {
        initComponents();
        carregarTabela(listaRobos);
    }

    private void initComponents() {
        robosTable = new JTable();
        tableModel = new DefaultTableModel(new Object[]{"Nome", "Tipo", "Status"}, 0);
        robosTable.setModel(tableModel);

        JScrollPane scrollPane = new JScrollPane(robosTable);
        add(scrollPane);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
    }

    private void carregarTabela(List<Robo> listaRobos) {
        tableModel.setRowCount(0);
        for (Robo robo : listaRobos) {
            tableModel.addRow(new Object[]{robo.getNome(), robo.getStatus(), robo.getTipo()});
        }
    }
}
