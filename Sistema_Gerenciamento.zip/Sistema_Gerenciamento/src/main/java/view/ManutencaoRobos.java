package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ManutencaoRobos extends JFrame {

    private JTextArea textArea;
    private JComboBox<String> roboComboBox;
    private JTextField statusField;
    private List<Robo> robos;
    private File arquivoRobos = new File("robos.txt");

    public ManutencaoRobos() {
        setTitle("Manutenção de Robôs");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        robos = carregarRobos();

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        roboComboBox = new JComboBox<>();
        for (Robo robo : robos) {
            roboComboBox.addItem(robo.getNome());
        }
        panel.add(new JLabel("Selecione o Robô:"));
        panel.add(roboComboBox);

        statusField = new JTextField();
        panel.add(new JLabel("Novo Status:"));
        panel.add(statusField);

        JButton atualizarButton = new JButton("Atualizar Status");
        atualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarStatus();
            }
        });
        panel.add(atualizarButton);

        textArea = new JTextArea();
        textArea.setEditable(false);
        atualizarTextoArea();

        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(textArea), BorderLayout.CENTER);
        setLocationRelativeTo(null);
    }

    private List<Robo> carregarRobos() {
        List<Robo> robos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(arquivoRobos))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] partes = line.split(",");
                if (partes.length == 3) {
                    robos.add(new Robo(partes[0], partes[1], partes[2]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return robos;
    }

    private void atualizarStatus() {
        String nomeRoboSelecionado = (String) roboComboBox.getSelectedItem();
        String novoStatus = statusField.getText();
        
        for (Robo robo : robos) {
            if (robo.getNome().equals(nomeRoboSelecionado)) {
                robo.setStatus(novoStatus);
                break;
            }
        }
        
        salvarRobos();
        atualizarTextoArea();
    }

    private void salvarRobos() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(arquivoRobos))) {
            for (Robo robo : robos) {
                writer.write(robo.getNome() + "," + robo.getTipoCompeticao() + "," + robo.getStatus());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void atualizarTextoArea() {
        StringBuilder sb = new StringBuilder();
        for (Robo robo : robos) {
            sb.append("Nome: ").append(robo.getNome())
              .append(", Tipo: ").append(robo.getTipoCompeticao())
              .append(", Status: ").append(robo.getStatus())
              .append("\n");
        }
        textArea.setText(sb.toString());
    }

    public static class Robo {
        private String nome;
        private String tipoCompeticao;
        private String status;

        public Robo(String nome, String tipoCompeticao, String status) {
            this.nome = nome;
            this.tipoCompeticao = tipoCompeticao;
            this.status = status;
        }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getTipoCompeticao() {
            return tipoCompeticao;
        }

        public void setTipoCompeticao(String tipoCompeticao) {
            this.tipoCompeticao = tipoCompeticao;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}
