package view;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Robo;
import model.Usuario;

public class ListaRobos extends JFrame {

    private JTable tabelaRobos;
    private Usuario usuario;
    private TelaEntrada.CadastroRobos cadastroRobos; 

    public ListaRobos(List<Robo> robos, Usuario usuario, TelaEntrada.CadastroRobos cadastroRobos) {
        this.usuario = usuario;
        this.cadastroRobos = cadastroRobos;
        initUI(robos);
    }

    public ListaRobos(List<Robo> robos) {
        initUI(robos);
    }

    private void initUI(List<Robo> robos) {
        setTitle("Lista de Robôs Cadastrados");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        String[] colunas = {"Nome", "Tipo de Competição", "Status"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);

        for (Robo robo : robos) {
            Object[] linha = {
                robo.getNome(),
                robo.getTipo(),
                robo.getStatus()  
            };
            modelo.addRow(linha);
        }

        tabelaRobos = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabelaRobos);

        JPanel painel = new JPanel(new BorderLayout());
        painel.add(scrollPane, BorderLayout.CENTER);

        JButton botaoVoltar = new JButton("Voltar");
        botaoVoltar.addActionListener(e -> {
            dispose();
            if (usuario != null && cadastroRobos != null) {
                new TelaEntrada(usuario.getNome(), cadastroRobos).setVisible(true); 
            }
        });

        JPanel painelInferior = new JPanel();
        painelInferior.add(botaoVoltar);
        painel.add(painelInferior, BorderLayout.SOUTH);

        add(painel);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                if (usuario != null && cadastroRobos != null) {
                    new TelaEntrada(usuario.getNome(), cadastroRobos).setVisible(true);
                }
            }
        });

        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        List<Robo> robos = List.of(
            new Robo("Robo1", "Status1", "Tipo1"),
            new Robo("Robo2", "Status2", "Tipo2")
        );

        javax.swing.SwingUtilities.invokeLater(() -> new ListaRobos(robos).setVisible(true));
    }
}
