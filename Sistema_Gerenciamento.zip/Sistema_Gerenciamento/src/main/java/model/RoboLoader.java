package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RoboLoader {
    public static List<Robo> carregarRobosDeArquivo(String caminhoArquivo) {
        List<Robo> robos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length == 3) {
                    String nome = partes[0].trim();
                    String status = partes[2].trim();
                    String tipo = partes[1].trim();
                    robos.add(new Robo(nome, status, tipo));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return robos;
    }
}
