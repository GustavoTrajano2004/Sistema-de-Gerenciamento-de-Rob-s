package model;

public class Robo {
    private String nome;
    private String tipo;
    private String status;

    public Robo(String nome, String tipo, String status) {
        this.nome = nome;
        this.tipo = tipo;
        this.status = status;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public String getStatus() {
        return status;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
