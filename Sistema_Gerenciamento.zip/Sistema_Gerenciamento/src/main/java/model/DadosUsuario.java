package model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DadosUsuario {

    private static final String ARQUIVO_USUARIOS = "usuarios.txt";

    public static void addUsuario(Usuario usuario) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_USUARIOS, true))) {
            writer.write(usuario.getNome() + ";" + usuario.getEmail() + ";" + usuario.getSenha());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Usuario getUsuarioByEmail(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_USUARIOS))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 3 && parts[1].equals(email)) {
                    return new Usuario(parts[0], parts[1], parts[2]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Usuario> getAllUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_USUARIOS))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 3) {
                    usuarios.add(new Usuario(parts[0], parts[1], parts[2]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return usuarios;
    }
}
